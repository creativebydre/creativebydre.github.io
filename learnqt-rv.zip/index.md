---
layout: start
title: C++,Qt and QML Training Services
description : Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
banner: /assets/img/bgqt.webp

button_video: On Demand Video Courses
button_video_link: '#courses'
button_book: Highly Visual Booklets
button_book_link: '#book'

courses: 
 title: Featured Courses
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 display: 3
 button: Explore All Courses
 button_post: Learn More

books: 
 title: Featured Bookled
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 button: Explore All Books
 button_post: Learn More

book1: 
 title: Qt6 QML For Beginners
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 content: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 cover: /assets/img/learnqtbook.webp
 link: https://mailchi.mp/a7c4442d916d/qt-creator-shortcuts

book2: 
 title: The C++20 Masterclass
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 content: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 cover: /assets/img/learnqtbook2.webp
 link: https://mailchi.mp/a7c4442d916d/qt-creator-shortcuts

book3: 
 title: Qt For Python (PySide6)
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 content: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 cover: /assets/img/learnqtbook3.webp
 link: /https://mailchi.mp/a7c4442d916d/qt-creator-shortcuts

why: 
 title: Why Chose Us
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 content: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 
 list: 
  - title: Source
    image: /assets/img/book.svg
    description: Include full source code !!
  - title: Access
    image: /assets/img/phonesa.svg
    description: Multi access on mobile and TV
  - title: Focus
    image: /assets/img/certf.svg
    description: Lorep ipsum dolor siamet
  - title: Certificate
    image: /assets/img/award.svg
    description: Certificate of completion

notified: 
 title: GET NOTIFIED OF NEW BOOK AND COURSE FOR REALASES FROM US 
 description: Youre email will never been shared 

follow: FOLLOW US

student: 
 title: Happy Student
 description: Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 

count1_number: '7'
count1_title: Courses

count2_number: '4'
count2_title: Books

count3_number: '32982'
count3_title: Students

count4_number: '8481'
count4_title: Reviews

testimonial1: 
 name: Jeewantha A.
 photo: /assets/img/testi1.webp
 description: If you are looking for a video course to learn C++ in depth, I really done

testimonial2: 
 name: Dennis S.
 photo: /assets/img/testi2.webp
 description: I think this is crucial. And he emphasized that. I am very happy about that. And it makes me hungry for more of his courses.

testimonial3: 
 name: Jason G.
 photo: /assets/img/testi3.webp
 description: great course, specially for people with 0 experience.I like the instructor’s focus on self education. He seems clear and concise.

blog: 
 title: Blog Update
 description: Learn Qt news article update post.
 button: Explore All Article


---
